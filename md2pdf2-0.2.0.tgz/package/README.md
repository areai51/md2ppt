# MD2PDF

A CLI tool that converts Markdown to PDF using customizable templates — think Astro, but for PDFs.

## Features

- Convert Markdown to PDF with a single command
- Customizable templates with layout, styling, and components
- Supports multiple output formats (letter, a4, etc.)
- Template inheritance and partials
- Frontmatter support for metadata
- Built-in template engine (Handlebars-like syntax)
- CLI flags for quick customization
- Watch mode for development

## Quick Start

```bash
# Install globally (once published)
npm install -g md2pdf2

# Or use npx
npx md2pdf2 convert input.md -o output.pdf

# With a custom template
md2pdf2 convert input.md --template my-template.hbs -o output.pdf

# Dev mode with live preview
md2pdf2 dev input.md
```

## Dev Mode

Start a live preview server to see your markdown rendered in different templates:

```bash
md2pdf2 dev input.md --port 3456
```

Opens a browser with:
- **Left pane**: Template selector (switch between templates)
- **Right pane**: Live preview of your markdown

Changes to your `.md` file or templates auto-reload the preview.

### Built-in Templates

- `default` - Clean, professional look
- `modern` - Bold colors, Inter-style typography
- `minimal` - Simple, classic serif
- `newsletter` - Email newsletter style
- `resume` - CV/resume formatting

## Project Structure

```
my-doc/
├── content/
│   └── my-doc.md
├── templates/
│   ├── default.hbs
│   ├── parts/
│   │   └── header.hbs
│   └── styles.css
├── md2pdf2.config.js
└── package.json
```

## Templates

Templates use handlebars-like syntax for placeholders and partials:

```handlebars
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>{{{styles}}}</style>
</head>
<body>
  {{> header}}
  <main>
    {{{content}}}
  </main>
</body>
</html>
```

## Configuration

`md2pdf2.config.js`:

```js
export default {
  template: './templates/default.hbs',
  style: './templates/styles.css',
  pdfOptions: {
    format: 'A4',
    margin: { top: '1cm', right: '1cm', bottom: '1cm', left: '1cm' }
  }
}
```

## Development

```bash
# Clone and setup
git clone https://github.com/areai51/md2pdf.git
cd md2pdf
npm install

# Build
npm run build

# Test
npm test

# Link for global use
npm link
```

## License

MIT
